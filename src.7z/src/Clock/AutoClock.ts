import { IClock } from "./IClock"

//export class AutoClock implements Clock {


//}


