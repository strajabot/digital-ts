

class Wire {
    
}